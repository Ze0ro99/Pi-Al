# Terms of Service

**Last Updated: 2025-05-02**

By using PiMetaConnect, you agree to the following terms:

- You must be a registered Pi Network user.
- You are responsible for maintaining the security of your wallet and credentials.
- You may not use the platform for illegal activities.
- Transactions are processed using the Pi Network; we are not responsible for third-party service issues.
- NFT and metaverse features must be used in accordance with all applicable laws and Pi Network regulations.
- We reserve the right to update or terminate services at any time.

## Contact
For questions or concerns: ze0ro99@example.com