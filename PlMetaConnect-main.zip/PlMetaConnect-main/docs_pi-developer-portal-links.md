# Pi Developer Portal Links for PiMetaConnect

- **Privacy Policy:** [https://github.com/Ze0ro99/PiMetaConnect/blob/main/docs/privacy-policy.md](https://github.com/Ze0ro99/PiMetaConnect/blob/main/docs/privacy-policy.md)
- **Terms of Service:** [https://github.com/Ze0ro99/PiMetaConnect/blob/main/docs/terms-of-service.md](https://github.com/Ze0ro99/PiMetaConnect/blob/main/docs/terms-of-service.md)
- **Support:** [https://github.com/Ze0ro99/PiMetaConnect/issues/new/choose](https://github.com/Ze0ro99/PiMetaConnect/issues/new/choose)
- **Main Repository:** [https://github.com/Ze0ro99/PiMetaConnect](https://github.com/Ze0ro99/PiMetaConnect)
- **Pi Network Integration Documentation:** [https://github.com/Ze0ro99/PiMetaConnect/blob/main/docs/pi-network-integration.md](https://github.com/Ze0ro99/PiMetaConnect/blob/main/docs/pi-network-integration.md)